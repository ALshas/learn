/*
 * 1.把用户自定义的方法扩展到 jQuery/jQuery.fn 上
 *   + 也是合并：把自己传递进来对象中的方法合并到 $/$.fn 上
 * 2.实现两个及多个对象的合并「浅比较进行浅合并 && 深比较进行深度合并」
 *   + 类似于Object.assign
 */
// $/$.fn.extend({...})
// $.extend(true,{...})
// $.extend({}, obj1, obj2)
// $.extend(true, {}, obj1, obj2)
/* jQuery.extend = jQuery.fn.extend = function () {
    var options, name, src, copy, copyIsArray, clone,
        target = arguments[0] || {},
        i = 1,
        length = arguments.length,
        deep = false;
    if (typeof target === "boolean") {
        deep = target;
        target = arguments[i] || {};
        i++;
        // deep->布尔
        // target->传递的第一个对象
        // i->对应的是第二个传递进来对象的索引「可能不存在」
    }
    if (typeof target !== "object" && !isFunction(target)) target = {};
    // 没有传递第二个对象：只是想把第一个传递对象中的内容合并到$/$.fn上
    if (i === length) {
        target = this; //-> target=$/$.fn
        i--; //->此时i索引对应的是传递的那个对象
    }
    // target代表最终要被替换的对象，最后返回的是target
    // 接下来的循环就是拿到剩余传递的对象「可能是一个也可能是多个」,拿他们依次替换target
    for (; i < length; i++) {
        // options:每一轮循环拿到的剩余的其中一个替换target的对象
        options = arguments[i];
        if (options == null) continue;
        for (name in options) {
            // copy获取对象中的每一项（我们把这些项替换target中同名这一项）
            copy = options[name];
            copyIsArray = Array.isArray(copy);
            // 放置对象套娃，会形成死递归
            if (target === copy) continue;
            if (deep && copy && (jQuery.isPlainObject(copy) || copyIsArray)) {
                // 深合并 options中的这一项需要是纯粹的对象或者是数组，我们才有必要和target中对应这一项进行深度对比，从而实现深度合并，否则直接用options中的这一项替换target中这一项即可
                //   options中的这一项copy  对象/数组
                //   src代表的是target中的这一项「clone」
                src = target[name];
                if (copyIsArray && !Array.isArray(src)) {
                    // 如果copy是一个数组，但是src不是，clone是一个数组
                    clone = [];
                } else if (!copyIsArray && !jQuery.isPlainObject(src)) {
                    // 如果copy是一个纯粹对象，但是src不是，让clone等于空对象
                    clone = {};
                } else {
                    clone = src;
                }
                copyIsArray = false;
                // 基于递归的方式实现当前项的深度比较和深度合并
                target[name] = jQuery.extend(deep, clone, copy);
            } else if (copy !== undefined) {
                // 浅合并
                target[name] = copy;
            }
        }
    }
    return target;
}; */

let obj1 = {
    url: '/api/list',
    method: 'GET',
    headers: {
        'Content-Type': 'application/json'
    },
    cache: false,
    arr: [10, 20, 30]
};
obj1.obj1 = obj1;

let obj2 = {
    params: {
        lx: 0
    },
    method: 'POST',
    headers: {
        'X-Token': 'AFED4567FG'
    },
    arr: [10, 20, 300, 400],
    obj1: obj1
};
console.log(_.merge(true, {}, obj1, obj2, [10, 20]));


// 把obj2合并到obj1中，让obj2中的内容替换obj1中的内容，最后返回obj1「obj1会发生改变」 “浅合并”
// console.log(Object.assign(obj1, obj2));
// console.log(Object.assign({}, obj1, obj2));  //=>这样处理最后返回新的对象，obj1/obj2都没有改变

/* 
// 把jQuery当做对象，扩展到其上面的私有的属性和方法「完善类库」
$.extend({
    xxx: function () {
        console.log('xxx');
    }
});
$.xxx();

// 向其原型上扩展属性和方法，供其实例“基于JQ选择器获取的结果”调取使用 「写JQ插件」
$.fn.extend({
    xxx() {
        console.log('xxx');
    }
});
$('.box').xxx(); 
*/