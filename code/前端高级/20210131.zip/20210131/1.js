(function () {
    "use strict";
    var arr = [];
    var slice = arr.slice;
    var push = arr.push;
    var indexOf = arr.indexOf;

    // =======
    var version = "3.5.1",
        jQuery = function jQuery(selector, context) {
            return new jQuery.fn.init(selector, context);
        };
    jQuery.fn = jQuery.prototype = {
        constructor: jQuery,
        jquery: version,
        length: 0,
        push: push,
        sort: arr.sort,
        splice: arr.splice,
        // 基于索引把“JQ对象”转换为“DOM对象”
        get: function (num) {
            // 把“JQ对象”类数组集合转化为数组集合
            if (num == null) return slice.call(this);
            // 支持负数作为索引
            return num < 0 ? this[num + this.length] : this[num];
        },
        // 也是基于索引查找JQ对象集合中的某一项，但是最后返回的不是“DOM对象”，而是一个新的“JQ对象”
        eq: function (i) {
            // 支持负数作为索引
            var len = this.length,
                j = +i + (i < 0 ? len : 0);
            return this.pushStack(j >= 0 && j < len ? [this[j]] : []);
        },
        pushStack: function (elems) {
            // this.constructor->jQuery => jQuery() => 空的JQ对象
            var ret = jQuery.merge(this.constructor(), elems);
            // prevObject:在链式调用中，可以快速回到原始操作的JQ对象（根JQ对象）
            ret.prevObject = this;
            return ret;
        },
    };
    
    // 传递两个集合，把第二个集合中的每一项全部放置到第一个集合的末尾“合并两个集合”，返回的是第一个几集合
    //   + 类似于数组的concat，但是这个只能数组使用
    //   + merge方法可以支持类数组集合的处理
    jQuery.merge = function merge(first, second) {
        var len = +second.length,
            j = 0,
            i = first.length;
        for (; j < len; j++) {
            first[i++] = second[j];
        }
        first.length = i;
        return first;
    };

    // =======
    var rootjQuery = jQuery(document),
        rquickExpr = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]+))$/,
        init = jQuery.fn.init = function init(selector, context, root) {
            var match, elem;
            // HANDLE: $(""), $(null), $(undefined), $(false)  返回空的JQ对象
            if (!selector) return this;
            root = root || rootjQuery;
            if (typeof selector === "string") {
                // $("<div>xxx</div>") &&  $('.box')
                if (selector[0] === "<" &&
                    selector[selector.length - 1] === ">" &&
                    selector.length >= 3) {
                    match = [null, selector, null];
                } else {
                    match = rquickExpr.exec(selector);
                }
                if (match && (match[1] || !context)) {
                    if (match[1]) {
                        context = context instanceof jQuery ? context[0] : context;
                        jQuery.merge(this, jQuery.parseHTML(
                            match[1],
                            context && context.nodeType ? context.ownerDocument || context : document,
                            true
                        ));
                        if (rsingleTag.test(match[1]) && jQuery.isPlainObject(context)) {
                            for (match in context) {
                                if (isFunction(this[match])) {
                                    this[match](context[match]);
                                } else {
                                    this.attr(match, context[match]);
                                }
                            }
                        }
                        return this;
                    } else {
                        elem = document.getElementById(match[2]);
                        if (elem) {
                            this[0] = elem;
                            this.length = 1;
                        }
                        return this;
                    }
                } else if (!context || context.jquery) {
                    return (context || root).find(selector);
                } else {
                    return this.constructor(context).find(selector);
                }
            } else if (selector.nodeType) {
                // 传递的是一个原生的DOM/JS对象：把DOM对象转换为JQ对象“这样就可以使用JQ原型上提供的方法”
                this[0] = selector;
                this.length = 1;
                return this;
            } else if (isFunction(selector)) {
                return root.ready !== undefined ?
                    root.ready(selector) :
                    selector(jQuery);
            }
            // 剩下的其他情况也是返回一个JQ对象“类数组集合”
            return jQuery.makeArray(selector, this);
        };
    init.prototype = jQuery.fn;

    // =======
    var readyList = jQuery.Deferred();
    jQuery.fn.ready = function (fn) {
        readyList
            .then(fn)
            .catch(function (error) {
                jQuery.readyException(error);
            });
        return this;
    };

    // =======
    jQuery.makeArray = function makeArray(arr, results) {
        var ret = results || [];
        if (arr != null) {
            if (isArrayLike(Object(arr))) {
                jQuery.merge(ret,
                    typeof arr === "string" ? [arr] : arr
                );
            } else {
                push.call(ret, arr);
            }
        }
        return ret;
    };

    // =======
    window.jQuery = window.$ = jQuery;
})();

//-------
// $(function () {})  -> $(document).ready(function () {})
//   + DOMContentLoaded  document.addEventListener("DOMContentLoaded", function(){})
// 等待页面中的DOM结构都加载完成，会触发事件执行“把对应的函数执行”

// DOMContentLoaded VS load
//   + window.addEventListener('load',function(){})
// 等待页面中的所有资源都加载完成「含：DOM结构加载完成 & 其他资源加载完成」

//-------
// “JQ对象” -> JQ实例对象“也就是基于选择器获取的结果”  「一般返回的是一个类数组集合:索引和length等属性」
// “DOM/JS对象” -> 基于浏览器内置的方法获取的元素对象“他们是浏览器内置类的相关实例对象”
// “JQ对象” VS “DOM对象”
//   + “DOM对象”->“JQ对象” : $(“DOM对象”)
//   + “JQ对象”->“DOM对象” : “JQ对象”[索引] OR “JQ对象”.get(索引)  使用内置类原型上的方法
// jQuery.fn  get VS eq

//-------
// $([selector]) 
//   + 返回的是 init 方法（类）的实例  -> A
//     A.__proto__===init.prototype
//   + init.prototype = jQuery.fn = jQuery.prototype  让init的原型重定向为jQuery的原型
//     A.__proto__===jQuery.prototype
// 总结：基于JQ选择器“$(...)、jQuery(...)”获取的是jQuery类的实例
//   + 目的，让用户使用的时候把“jQuery/$”当做普通函数执行，但是最后的结果是创在其类的一个实例
//   + 用户使用起来方便  
//   + 这种处理模式就是“工厂设计模式”

//-------
// $('.box')  在整个文档中找到拥有box样式类的
// $('#commHead .box') 在ID为commHead的容器中，找到拥有box样式类的「后代查找」
// $('.box',document.getElementById('commHead')) 和第二条是一个意思

//-------
/* function* fn() {}
fn.prototype.x = 100;
let f = fn();
// f.__proto__===fn.prototype  f也是fn的一个实例（这也是另外一种不基于new执行函数，也可以创在构造函数实例的情况） */