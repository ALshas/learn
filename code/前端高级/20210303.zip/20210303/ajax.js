import $ from './lib/utils';
import Qs from 'qs';

/* 封装发送请求类 */
class Ajax {
    constructor(config) {
        let self = this;
        self.config = config;
        // 请求拦截器
        config = ajax.interceptors.request.pond[0](config);
        return self.request();
    }
    request() {
        let promise,
            xhr,
            onfulfilled,
            onrejected,
            self = this;
        // 每一次请求返回一个PROMISE实例，根据AJAX请求的结果，执行RESOLVE/REJECT，从而控制PROMISE的成功或者失败
        promise = new Promise((resolve, reject) => {
            xhr = new XMLHttpRequest;
            xhr.open();
            xhr.onreadystatechange = () => {

            };
            xhr.send();
        });
        // 响应拦截器
        [onfulfilled, onrejected] = ajax.interceptors.response.pond;
        return promise.then(onfulfilled, onrejected);
    }
}

/* 封装执行方法 */
let methodsGET = ['GET', 'DELETE', 'HEAD', 'OPTIONS'],
    methodsPOST = ['POST', 'PUT', 'PATCH'],
    methods = methodsGET.concat(methodsPOST),
    headers = {
        'Content-Type': 'application/json'
    };
methods.forEach(item => headers[item.toLowerCase()] = {});

// 配置项的校验规则
let configRule = {
    // TYPE类型{字符串/数组}  
    // DEFAULT默认值  
    // REQUIRED设置是否为必传项
    baseURL: {
        type: 'string',
        default: ''
    },
    url: {
        type: 'string',
        required: true
    },
    method: {
        type: 'string',
        default: 'GET'
    },
    transformRequest: {
        type: 'function',
        default (data) {
            try {
                if ($.isPlainObject(data)) return JSON.stringify(data);
            } catch (err) {}
            return data;
        }
    },
    headers: {
        type: 'object',
        default: headers
    },
    params: {
        type: ['string', 'object'],
        default: {}
    },
    data: {
        type: ['string', 'object'],
        default: {}
    },
    cache: {
        type: 'boolean',
        default: false
    },
    timeout: {
        type: 'number',
        default: 0
    },
    withCredentials: {
        type: 'boolean',
        default: false
    },
    responseType: {
        type: 'string',
        // 'text' 'json' 'xml' ...
        default: 'json'
    },
    validateStatus: {
        type: 'function',
        default (status) {
            return status >= 200 & status < 300;
        }
    }
};

// 执行方法
const ajax = function ajax(config) {
    !$.isPlainObject(config) ? config = {} : null;
    // 把传递的配置项config和ajax.defaults.xxx配置的统一配置项先合并
    config = $.merge(true, {}, ajax.defaults, config);
    // 然后按照configRule进行规则校验:迭代configRule中的每一项，再去看config中是否有这一项
    //  + 没有:首先校验是否为必传项，如果是必传，则报错，否则以默认值为主
    //  + 传递:首先校验格式是否正确，不正确报错，正确则以自己传递的为主「传递的值和默认值深度合并」
    $.each(configRule, (value, key) => {
        let {
            type,
            required,
            default: defaultValue
        } = value;
        !Array.isArray(type) ? type = [type] : null;
        let configValue = config[key],
            configType = $.toType(configValue);
        if (configType === 'undefined') {
            if (required) throw new TypeError(`${key} must be required!`);
            config[key] = defaultValue;
        } else {
            if (!type.includes(configType)) throw new TypeError(`${key} must be an ${type}!`);
            config[key] = $.merge(true, {}, defaultValue, configValue);
        }
    });
    // 按照最终的配置项发送数据请求
    return new Ajax(config);
};

// 快捷办法
methodsGET.forEach(item => {
    ajax[item.toLowerCase()] = function (url, config) {
        !$.isPlainObject(config) ? config = {} : null;
        config.method = item;
        config.url = url;
        return ajax(config);
    };
});
methodsPOST.forEach(item => {
    ajax[item.toLowerCase()] = function (url, data, config) {
        !$.isPlainObject(config) ? config = {} : null;
        config.method = item;
        config.url = url;
        config.data = data == null ? {} : data;
        return ajax(config);
    };
});

// 并发请求
ajax.all = function all(queue) {
    if (!Array.isArray(queue)) throw new TypeError(`queue muse be an array!`);
    return Promise.all(queue);
};

// 全局公共配置
ajax.defaults = {
    headers: $.clone(headers)
};

// 拦截器 interceptors
class Interceptors {
    pond = [];
    use(onfulfilled, onrejected) {
        if (!$.isFunction(onfulfilled)) {
            onfulfilled = function onfulfilled(result) {
                return result;
            };
        }
        if (!$.isFunction(onrejected)) {
            onrejected = function onrejected(reason) {
                return Promise.reject(reason);
            };
        }
        this.pond.push(onfulfilled);
        this.pond.push(onrejected);
    }
}
ajax.interceptors = {
    request: new Interceptors,
    response: new Interceptors
};

/* 暴露API */
if (typeof window !== "undefined") window.ajax = ajax;
if (typeof module === "object" && typeof module.exports === "object") module.exports = ajax;