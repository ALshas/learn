import $ from './lib/utils';

/* 编写一个公共的方法，传递一些实参进来，基于传递值的不同处理不同的事情 */

// 如果不明确两个参数类型不一样，我们无法做到“n不传有默认值，传递的一个值是给m的”
/* 
function fn(n, m) {
    if (typeof n === "undefined") n = 0;
    if (typeof m === "undefined") m = 0;
} 
*/

// 明确了参数的数据格式不一样，具体啥格式也知道，我们可以做处理
// 例如：n布尔 m数字
/* 
function fn(n, m) {
    if (typeof n !== "boolean") {
        m = n;
        n = true;
    }
    if (typeof m !== "number") {
        m = 0;
    }
} 
fn(true, 20);
fn(10);
fn(false);
*/

//=>如果我们采用一个个的形参去接受传递的实参，是存在很多限制的：
// + 严格按照顺序进行值的传递
// + 很难做到跳过某个形参，直接给后面的形参传值（除非明确了类型不一样，这样我们也需要基于复杂的逻辑判断处理）
// + 如果有多个实参(形参)，我们很难设置中间不传递的默认值信息等操作  多个参考范围>=3


//=>多个参数处理我们一般都基于对象处理{options / config...}
//  + 不需要考虑顺序了，合并匹配的时候是按照对象的成员处理
//  + 自己需要更改的值自己传递进去，不需要更改的不需要写，最后走默认值即可
/* 
function fn(options) {
    !$.isPlainObject(options) ? options = {} : null;
    // 默认配置项
    let params = {
        x: 0,
        y: 0,
        n: 0,
        m: 0
    };
    // 合并配置项
    options = $.merge(true, {}, params, options);
}
fn({
    x: 10,
    m: 20
});
fn({
    y: 10
}); 
*/