import $ from './lib/utils';
import Qs from 'qs';

/* 封装发送请求类 */
class Ajax {
    constructor(config) {
        let self = this;
        self.config = ajax.interceptors.request.pond[0](config);
        return self.request();
    }
    request() {
        let promise,
            xhr,
            onfulfilled,
            onrejected,
            self = this;
        let {
            method,
            validateStatus,
            timeout,
            withCredentials
        } = self.config;
        method = method.toUpperCase();
        promise = new Promise((resolve, reject) => {
            xhr = new XMLHttpRequest;
            xhr.open(method, self.handleURL());
            // 设置一些其余的信息 超时&资源凭证&请求头
            timeout > 0 ? xhr.timeout = timeout : null;
            xhr.withCredentials = withCredentials;
            self.handleREQUESTHEADER(xhr);
            xhr.onreadystatechange = () => {
                if (!validateStatus(xhr.status)) {
                    // 失败:HTTP状态码失败
                    reject(self.handleRESULT(xhr, false, 'STATUS'));
                    return;
                }
                if (xhr.readyState === 4 || (method === 'HEAD' && xhr.readyState === 2)) {
                    // 成功
                    resolve(self.handleRESULT(xhr, true));
                }
            };
            xhr.ontimeout = () => {
                // 失败:请求超时
                reject(self.handleRESULT(xhr, false, 'TIMEOUT'));
            };
            xhr.onabort = () => {
                // 失败:请求中断
                reject(self.handleRESULT(xhr, false, 'ABORT'));
            };
            xhr.send(self.handleBODY());
        });
        [onfulfilled, onrejected] = ajax.interceptors.response.pond;
        return promise.then(onfulfilled, onrejected);
    }
    handleURL() {
        let self = this,
            {
                url,
                baseURL,
                method,
                cache,
                params
            } = self.config;
        const check = url => url.includes('?') ? '&' : '?';
        if (!/^http(s?):\/\//i.test(url)) url = baseURL + url;
        // 问号参数
        if (params && !$.isEmptyObject(params)) {
            if ($.isPlainObject(params)) params = Qs.stringify(params);
            url += `${check(url)}${params}`;
        }
        // 缓存处理
        if (methodsGET.includes(method.toUpperCase()) && cache === false) {
            url += `${check(url)}_=${+new Date()}`;
        }
        return url;
    }
    handleBODY() {
        let self = this,
            {
                method,
                data,
                headers,
                transformRequest
            } = self.config;
        // 只有POST系列请求才需要处理请求主体
        if (!methodsPOST.includes(method.toUpperCase())) return null;
        return transformRequest(data, headers);
    }
    handleREQUESTHEADER(xhr) {
        let self = this,
            {
                headers,
                method
            } = self.config;
        //把公共的请求头和指定请求方式配置的请求头合并在一起
        headers = $.clone(true, headers);
        let methodHEADERS = headers[method.toLowerCase()];
        $.each(headers, (_, key) => {
            if (methods.includes(key.toUpperCase())) {
                delete headers[key];
            }
        });
        headers = $.merge(true, headers, methodHEADERS);
        // 设置自定义请求头信息
        $.each(headers, (value, key) => xhr.setRequestHeader(key, value));
    }
    handleRESULT(xhr, flag, code) {
        let self = this,
            response = {},
            reason = {},
            result = '';
        // 请求超时或者中断，则直接返回失败CODE
        if (flag === false && (code === "TIMEOUT" || code === "ABORT")) {
            reason.code = 'ECONNABORTED';
            return reason;
        }
        // 构建RESPONSE
        response = {
            status: xhr.status,
            statusText: xhr.statusText,
            xhr,
            config: self.config,
            headers: Qs.parse(xhr.getAllResponseHeaders().replace(/: /g, '=').replace(/\n(\s*)/g, '&'))
        };
        // 状态码失败情况，则不用再处理响应主体了
        if (flag === false) {
            reason.code = code;
            reason.response = response;
            return reason;
        }
        // 成功
        result = xhr.response;
        switch (self.config.responseType.toUpperCase()) {
            case 'TEXT':
                result = xhr.responseText;
                break;
            case 'JSON':
                result = JSON.parse(xhr.responseText);
                break;
            case 'XML':
                result = xhr.responseXML;
                break;
        }
        response.data = result;
        return response;
    }
}

/* 封装执行方法 */
let methodsGET = ['GET', 'DELETE', 'HEAD', 'OPTIONS'],
    methodsPOST = ['POST', 'PUT', 'PATCH'],
    methods = methodsGET.concat(methodsPOST),
    headers = {
        'Content-Type': 'application/json'
    };
methods.forEach(item => headers[item.toLowerCase()] = {});

// 配置项的校验规则
let configRule = {
    // TYPE类型{字符串/数组}  
    // DEFAULT默认值  
    // REQUIRED设置是否为必传项
    baseURL: {
        type: 'string',
        default: ''
    },
    url: {
        type: 'string',
        required: true
    },
    method: {
        type: 'string',
        default: 'GET'
    },
    transformRequest: {
        type: 'function',
        default (data) {
            try {
                if ($.isPlainObject(data)) return JSON.stringify(data);
            } catch (err) {}
            return data;
        }
    },
    headers: {
        type: 'object',
        default: headers
    },
    params: {
        type: ['string', 'object'],
        default: {}
    },
    data: {
        type: ['string', 'object'],
        default: {}
    },
    cache: {
        type: 'boolean',
        default: false
    },
    timeout: {
        type: 'number',
        default: 0
    },
    withCredentials: {
        type: 'boolean',
        default: false
    },
    responseType: {
        type: 'string',
        // 'text' 'json' 'xml' ...
        default: 'json'
    },
    validateStatus: {
        type: 'function',
        default (status) {
            return status >= 200 & status < 300;
        }
    }
};

// 执行方法
const ajax = function ajax(config) {
    !$.isPlainObject(config) ? config = {} : null;
    config = $.merge(true, {}, ajax.defaults, config);
    $.each(configRule, (value, key) => {
        let {
            type,
            required,
            default: defaultValue
        } = value;
        !Array.isArray(type) ? type = [type] : null;
        let configValue = config[key],
            configType = $.toType(configValue);
        if (configType === 'undefined') {
            if (required) throw new TypeError(`${key} must be required!`);
            config[key] = defaultValue;
        } else {
            if (!type.includes(configType)) throw new TypeError(`${key} must be an ${type}!`);
            // config[key] = $.merge(true, {}, defaultValue, configValue);
        }
    });
    return new Ajax(config);
};

// 快捷办法
methodsGET.forEach(item => {
    ajax[item.toLowerCase()] = function (url, config) {
        !$.isPlainObject(config) ? config = {} : null;
        config.method = item;
        config.url = url;
        return ajax(config);
    };
});
methodsPOST.forEach(item => {
    ajax[item.toLowerCase()] = function (url, data, config) {
        !$.isPlainObject(config) ? config = {} : null;
        config.method = item;
        config.url = url;
        config.data = data == null ? {} : data;
        return ajax(config);
    };
});

// 并发请求
ajax.all = function all(queue) {
    if (!Array.isArray(queue)) throw new TypeError(`queue muse be an array!`);
    return Promise.all(queue);
};

// 全局公共配置
ajax.defaults = {
    headers: $.clone(headers)
};

// 拦截器 interceptors
class Interceptors {
    constructor() {
        this.pond = [];
    }
    use(onfulfilled, onrejected) {
        if (!$.isFunction(onfulfilled)) {
            onfulfilled = function onfulfilled(result) {
                return result;
            };
        }
        if (!$.isFunction(onrejected)) {
            onrejected = function onrejected(reason) {
                return Promise.reject(reason);
            };
        }
        this.pond.push(onfulfilled);
        this.pond.push(onrejected);
    }
}
ajax.interceptors = {
    request: new Interceptors,
    response: new Interceptors
};

/* 暴露API */
if (typeof window !== "undefined") window.ajax = ajax;
if (typeof module === "object" && typeof module.exports === "object") module.exports = ajax;