function sum(a, b) {
    return a + b;
}

// 基于ES6Module方式导出
export default {
    sum
};