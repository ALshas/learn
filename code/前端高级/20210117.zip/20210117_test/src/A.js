function sum(a, b) {
    return a + b;
}

// CommonJS的导出
module.exports = {
    sum
};