<template>
  <div id="app">珠峰培训</div>
</template>

<script>
export default {
  name: "App",
};
</script>