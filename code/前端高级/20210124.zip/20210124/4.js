/* 
function C1(name) {
    if (name) {
        this.name = name;
    }
}
function C2(name) {
    this.name = name;
}

function C3(name) {
    this.name = name || 'join';
}
C1.prototype.name = 'Tom';
C2.prototype.name = 'Tom';
C3.prototype.name = 'Tom';
alert((new C1().name) + (new C2().name) + (new C3().name));
// "Tomundefinedjoin" 
*/

/* function Foo() {
    getName = function () {
        console.log(1);
    };
    return this;
}
Foo.getName = function () {
    console.log(2);
};
Foo.prototype.getName = function () {
    console.log(3);
};
var getName = function () {
    console.log(4);
};
function getName() {
    console.log(5);
}
Foo.getName();
getName();
Foo().getName();
getName();
new Foo.getName();
new Foo().getName();
new new Foo().getName(); */


/* 
// 函数/构造函数
function Fn(name) {
    this.x = 100;
    this.name = name;
}
// 原型「类/实例」
Fn.prototype.y = 200;
Fn.prototype.getX = function () {};
Fn.prototype.getName = function () {};
// 对象「和前面没有直接的关系」
Fn.x = 1000;
Fn.getX = function () {};

Fn.getX();
new Fn().getX();
Fn(); 
*/

/* function Sum() {
    if (!(this instanceof Sum)) throw new TypeError('constructor Sum cannot be invoked without new');
    console.log('OK');
}
// Sum();
new Sum(); */

/* class Fn {
    // 构造函数体
    constructor(name) {
        // this -> 创造的实例对象 「this.xxx=xxx设置的私有属性」
        // this.x = 100;
        this.name = name;
    }
    x = 100; //等价于构造函数体中的“this.x=100”

    //原型上的内容 「无法直接设置原型上属性值不是函数的公有属性」
    //  + 但是这样这样设置的函数是没有prototype的，类似于：obj={fn(){}}
    getX() {}
    getName() {}

    // 看做普通对象，设置私有属性「静态私有属性和方法」
    static x = 1000;
    static getX() {}
}
Fn.prototype.y = 200;

// Fn(); //Uncaught TypeError: Class constructor Fn cannot be invoked without 'new'  基于class声明的构造函数必须基于new执行，不允许当做普通函数执行
let f = new Fn('zhufeng'); */

class Fn {
    // 私有的
    x = 100;
    /* getX1 = () => {
        // 如果使用的是箭头函数，则箭头函数没有自己的THIS，所用的是上下文中的THIS，而此处上下文中的THIS都是Fn的实例
        //   f.getX1()   this->实例
        //   f.getX1.call(10)  this->实例
        console.log(this);
    } */

    // 原型
    /* 
    getX2() {
        // this一般都是当前类的实例  -> f.getX2()
        //   + 也可能是Fn.prototype  -> Fn.prototype.getX2()
        //   + 也可能是其余的情况「例如：基于call/apply等改变函数中的this」
        console.log(this);
    } 
    */
    /* 
    // 直接这样处理，语法是不支持的，这样处理的目的，是不论以后原型上的方法咋执行，始终保证方法中的this是类的实例
    getX2: () => {
        console.log(this);
    } 
    */
}
let f = new Fn;
/* f.getX2();
Fn.prototype.getX2();
f.getX2.call(10); */