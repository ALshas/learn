function Fn() {
    this.x = 100;
}
Fn.prototype.getX = function getX() {
    console.log(this.x);
};
let f1 = new Fn;
let f2 = new Fn;