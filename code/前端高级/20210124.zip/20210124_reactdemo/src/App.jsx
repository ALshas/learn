import React from 'react';

class App extends React.Component {
  constructor() {
    super();
    this.x = 100;
  }

  render() {
    return <div>
      珠峰培训哈哈
      <button onClick={this.handle}>点我啊</button>
    </div>;
  }

  /* handle() {
    // this -> undefined 
    console.log(this);
  } */

  handle = () => {
    console.log(this);
  };

}

export default App;
