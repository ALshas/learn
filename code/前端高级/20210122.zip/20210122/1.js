/* 
 * 1.大部分“函数数据类型”的值都具备“prototype（原型/显式原型）”属性，属性值本身是一个对象「浏览器会默认为其开辟一个堆内存，用来存储当前类所属实例，可以调用的公共的属性和方法」，在浏览器默认开辟的这个堆内存中「原型对象」有一个默认的属性“constructor（构造函数/构造器）”，属性值是当前函数/类本身！！
 *  「函数数据类型」
 *     + 普通函数（实名或者匿名函数）
 *     + 箭头函数
 *     + 构造函数/类「内置类/自定义类」
 *     + 生成器函数 Generator
 *     + ...
 *  「不具备prototype的函数」
 *     + 箭头函数  const fn=()=>{}
 *     + 基于ES6给对象某个成员赋值函数值的快捷操作
 *       let obj = {
 *          fn1: function () {
 *             // 常规写法  具备prototype属性
 *          },
 *          fn2() {
 *             // 快捷写法  不具备prototype属性
 *          }
 *       };
 *       class Fn {
 *          fn() {} //这样的也不具备prototype属性
 *       };
 *     + ...
 * 
 * 2.每一个“对象数据类型”的值都具备一个属性“__proto__（原型链/隐式原型）”，属性值指向“自己所属类的原型prototype”
 *  「对象数据类型值」
 *     + 普通对象
 *     + 特殊对象：数组、正则、日期、Math、Error...
 *     + 函数对象
 *     + 实例对象
 *     + 构造函数.prototype
 *     + ...
 */
let arr = [10, 20, 30];
console.log(arr.hasOwnProperty('forEach')); //->false
// 简称：验证“forEach”是否为arr对象的私有属性
// 全称：arr按照原型链查找机制，找到的是Object.prototype.hasOwnProperty方法「@A」，并且把找到的@A执行
//   + 方法中的this->arr「我们要操作的对象」
//   + 传递的实参->“forEach”「我们要验证的属性」
// @A方法的作用是，验证“实参”是否为当前“this”的一个私有属性
// ===> Object.prototype.hasOwnProperty.call(arr,'forEach')