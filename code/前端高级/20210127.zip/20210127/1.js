/* function Fn() {
    let a = 1;
    this.a = a;
}
Fn.prototype.say = function () {
    this.a = 2;
}
Fn.prototype = new Fn;
let f1 = new Fn;
​
Fn.prototype.b = function () {
    this.a = 3;
};
console.log(f1.a);
console.log(f1.prototype);
console.log(f1.b);
console.log(f1.hasOwnProperty('b'));
console.log('b' in f1);
console.log(f1.constructor == Fn); */

/* 
 * 检测某个属性是否为当前对象的属性 
 *   in ：不论是私有还是公有属性「原型链」，只要有结果就是true
 *   hasOwnProperty ：检测是否为对象的私有属性，只要私有中没有这个属性，结果是false
 */
// 检测当前属性是否为对象的公有属性
/* function hasPubProperty(obj, attr) {
    // 局限性：如果私有中有这个属性，公有也有，此方法检测是不准确的
    return (attr in obj) && !obj.hasOwnProperty(attr);
} */

Object.prototype.hasPubProperty = function hasPubProperty(attr) {
    // this -> obj
    let self = this,
        prototype = Object.getPrototypeOf(self);
    while (prototype) {
        if (prototype.hasOwnProperty(attr)) {
            return true;
        }
        prototype = Object.getPrototypeOf(prototype);
    }
    return false;
    /* // in操作符检测的特点：先看自己私有中是否有，如果没有会默认按照原型链一层层查找
    let self = this,
        prototype = Object.getPrototypeOf(self);
    return attr in prototype; */
};
// obj.hasPubProperty(attr);