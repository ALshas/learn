/*
 * 基于Promise.all实现Ajax的串行和并行
 */
/* // 并行：多个请求之间没有任何的关联，此时我们可以同时发送多个请求「一般指，当所有请求成功后，我们统一处理啥事情」
let req1 = axios.get('/user/list');
let req2 = axios.get('/user/info', {
    params: {
        userId: 1
    }
});
let req3 = axios.get('/department/list');
Promise.all([req1, req2, req3]).then(results => {
    console.log('请求都处理成功:', results);
}); */

// 串行：一个请求发送完成，再去发送第二个请求「两个请求中有关联」
/* axios.get('/user/list').then(data => {
    console.log('用户列表', data);
    return axios.get('/user/info', {
        params: {
            userId: 1
        }
    });
}).then(data => {
    console.log('用户信息', data);
}); */
/* (async () => {
    let data = await axios.get('/user/list');
    console.log('用户列表', data);

    data = await axios.get('/user/info', {
        params: {
            userId: 1
        }
    });
    console.log('用户信息', data);
})(); */