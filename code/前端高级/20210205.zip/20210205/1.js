/* setTimeout(() => {
    console.log('a');
});
Promise.resolve().then(() => {
    console.log('b');
}).then(() => {
    return Promise.resolve('c').then(data => {
        setTimeout(() => {
            console.log('d')
        });
        console.log('f');
        return data;
    });
}).then(data => {
    console.log(data);
}); */


/* 
// p1状态：执行resolve是成功   执行reject是失败「executor函数中执行报错，p1也是失败」
let p1 = new Promise((resolve, reject) => {

});
// p2状态：onfulfilledCallback、onrejectedCallback
//   + 执行没有返回新的promsie实例，则看执行是否报错，不报错p2是成功，报错则是失败
//   + 如果执行返回的是一个promise实例@A,@A实例的状态影响p2的状态
let p2 = p1.then(function onfulfilledCallback() {

}, function onrejectedCallback() {

});

let p3 = p2.then(function onfulfilledCallback() {
    return Promise.resolve();
}, function onrejectedCallback() {

}); 
*/


function func1() {
    console.log('func1 start');
    return new Promise(resolve => {
        resolve('OK');
    });
}

function func2() {
    console.log('func2 start');
    return new Promise(resolve => {
        setTimeout(() => {
            resolve('OK');
        }, 10);
    });
}
console.log(1);
setTimeout(async () => {
    console.log(2);
    await func1();
    console.log(3);
}, 20);
for (let i = 0; i < 90000000; i++) {}
console.log(4);
func1().then(result => {
    console.log(5);
});
func2().then(result => {
    console.log(6);
});
setTimeout(() => {
    console.log(7);
}, 0);
console.log(8);