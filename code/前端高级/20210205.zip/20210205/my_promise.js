(function () {
    "use strict";

    /* 自定义Promise类 */
    function Promise(executor) {
        var self = this,
            change;

        // 必须NEW执行 && EXECUTOR必须是一个函数
        if (!(self instanceof Promise)) throw new TypeError('undefined is not a promise!');
        if (typeof executor !== "function") throw new TypeError('Promise resolver ' + executor + ' is not a function!');

        // 实例具备的属性  状态&结果
        self.state = 'pending';
        self.result = undefined;
        self.onFulfilledCallbacks = [];
        self.onRejectedCallbacks = [];

        // 修改实例的状态和结果「一但状态被改变则不能再被更改」
        change = function change(state, result) {
            if (self.state !== 'pending') return;
            self.state = state;
            self.result = result;

            // 创建异步微任务，通知集合中存储的方法执行「前提：集合中需要有东西才执行」
            var callbacks = state === 'fulfilled' ? self.onFulfilledCallbacks : self.onRejectedCallbacks,
                i = 0,
                len = callbacks.length,
                callback;
            if (callbacks.length > 0) {
                setTimeout(function () {
                    for (; i < len; i++) {
                        callback = callbacks[i];
                        if (typeof callback === "function") callback(result);
                    }
                }, 0);
            }
        };

        // new Promise的时候会立即执行executor函数
        try {
            executor(function resolve(result) {
                change('fulfilled', result);
            }, function reject(reason) {
                change('rejected', reason);
            });
        } catch (err) {
            // 执行executor报错，实例也是失败的状态
            change('rejected', err);
        }
    }

    // 构造函数原型
    Promise.prototype = {
        constructor: Promise,
        self: true,
        then: function (onFulfilled, onRejected) {
            var self = this;
            // 情况1：如果已经知道对应实例的状态是成功还是失败了，则创建一个“异步微任务”，后期执行onFulfilled/onRejected
            // 情况2：如果此时还不知道实例状态，就先把onFulfilled/onRejected存储起来，后期更改其状态之后，再通知方法执行即可，也是”异步微任务“
            // 基于 queueMicrotask 可以创造异步的微任务「兼容性差」；也可以基于定时器创造一个异步的宏任务，来模拟微任务；
            switch (self.state) {
                case 'fulfilled':
                    setTimeout(function () {
                        onFulfilled(self.result);
                    }, 0);
                    break;
                case 'rejected':
                    setTimeout(function () {
                        onRejected(self.result);
                    }, 0);
                    break;
                default:
                    self.onFulfilledCallbacks.push(onFulfilled);
                    self.onRejectedCallbacks.push(onRejected);
            }
        },
        catch: function () {}
    };
    if (typeof Symbol !== "undefined") Promise.prototype[Symbol.toStringTag] = 'Promise';

    // 普通对象：私有静态方法
    Promise.all = function all() {};
    Promise.resolve = function resolve() {};
    Promise.reject = function reject() {};

    /* 暴露API */
    // if (typeof window !== "undefined") window.Promise = Promise;
    // if (typeof module === "object" && typeof module.exports === "object") module.exports = Promise;
})();

// 内置的Promise
let p1 = new Promise(function (resolve, reject) {
    setTimeout(() => {
        if (Math.random() < 0.5) {
            resolve('OK');
        } else {
            reject('NO');
        }
    }, 2000);
});
p1.then(function (result) {

}, function (reason) {

});

p1.then(function (result) {

}, function (reason) {

});