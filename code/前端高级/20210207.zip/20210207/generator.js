/*
 * 生成器对象是由一个generator function返回的,并且它符合可迭代协议和迭代器协议
 *   https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Generator
 * 
 * 普通函数 VS 生成器函数
 *    生成器函数 [[IsGenerator]]:true
 *    
 *   「把它当做一个实例 __proto__」
 *       普通函数是 Function 的实例，普通函数.__proto__===Function.prototype
 *       生成器函数是 GeneratorFunction 的实例，生成器函数.__proto__===GeneratorFunction.prototype -> 
 *                  GeneratorFunction.prototype.__proto__===Function.prototype
 *      ({}).toString.call(生成器函数) => "[object GeneratorFunction]"
 *    
 *   「把它作为一个构造函数 prototype」
 *      生成器函数不能被new执行  Uncaught TypeError: func is not a constructor
 *      当做普通函数执行，返回的结果就是生成器函数的一个实例
 *      itor.__proto__ -> func.prototype「空对象，没有constructor」 -> Generator.prototype「constructor:GeneratorFunction」{next/return/throw/Symbol(Symbol.toStringTag): "Generator"} -> 一个具备迭代器规范的对象「Symbol(Symbol.iterator)」 -> Object.prototype
 */
"use strict";

/* 
function fn() {
    console.log(this);
}
let gen = fn();
console.log(gen);
console.log(typeof fn); //->"function"
console.log(fn instanceof Function); //->true 
*/

/* 
// generator函数：function后面加一个*
function* fn() {
    console.log(this);
    return 10;
}
fn.prototype.query = function () {};
let gen = fn(); //->虽然看上去fn后面加小括号了，但是和我们理解的fn执行是不一样的「函数体中代码并没有执行」
console.log(gen); //->返回的结果不是undefined，而是具备迭代器规范的一个对象「生成器函数执行返回一个迭代器」
// gen.__proto__ -> fn.prototype「query」 -> GeneratorFunction.prototype「next/return/throw/Symbol.toStringTag」-> xxx.prototype「Symbol.iterator」 -> Object.prototype
console.log(typeof fn); //->"function"
console.log(fn instanceof Function); //->true 
*/

//-----------
/* function* generator(x) {
    console.log(x);
    return x * 10;
}
let itor = generator(100);
console.log(itor.next()); //-> 输出x:100  &&  {value:1000,done:true} */

// 每一次执行next方法都会去函数体中执行代码
//   从开始或者上一次yeild结束的位置继续向下执行，直到遇到新的yeild结束
//   每次返回的对象 value->yeild后面的值/return后面的值   done->false/true「遇到return是true」
/* function* generator() {
    console.log('A');
    yield 10;
    console.log('B');
    yield 20;
    console.log('C');
    yield 30;
    console.log('D');
    return 100;
}
let itor = generator();
console.log(itor.next()); //->{value:10,done:false}
console.log(itor.next()); //->{value:20,done:false}
console.log(itor.next()); //->{value:30,done:false}
console.log(itor.next()); //->{value:100,done:true}
console.log(itor.next()); //->{value:undefined,done:true} */


/* 
function* generator() {
    console.log('A');
    yield 10;
    console.log('B');
    yield 20;
    console.log('C');
    return 30;
}
let itor = generator();
console.log(itor.next()); //->{value:10,done:false}
console.log(itor.return('@return')); //->{value:"@return",done:true} 直接控制遍历结束
// console.log(itor.throw('@throw')); //直接抛出异常信息，没有返回结果，下面代码也不会再执行了
console.log(itor.next()); //->{value:undefined,done:true}
// ... 
*/

/* function* generator() {
    let x1 = yield 10;
    console.log(x1);
    let x2 = yield 20;
    console.log(x2);
    return 30;
}
let itor = generator();
itor.next('@1'); //第一次传递的值没有用
itor.next('@2'); //每一次执行next的传递的值，是作为上一次yeild的返回值处理的
itor.next('@3'); */

/* function* generator1() {
    yield 10;
    yield 20;
}

function* generator2() {
    yield 10;
    yield generator1();
    yield 20;
}
let itor = generator2();
console.log(itor.next()); //value:10  done:false
console.log(itor.next()); //value:itor->generator1 done:false
console.log(itor.next()); //value:20  done:false
console.log(itor.next()); //value:undefined done:true */

/* 
function* generator1() {
    yield 10;
    yield 20;
}

function* generator2() {
    yield 10;
    yield* generator1(); //yeild* 后面跟着一个新的itor，后期执行到这的时候，会进入到新的generator中执行
    yield 20;
}
let itor = generator2();
console.log(itor.next()); //value:10  done:false
console.log(itor.next()); //value:10 done:false
console.log(itor.next()); //value:20  done:false
console.log(itor.next()); //value:20 done:false
console.log(itor.next()); //value:undefined done:true 
*/

//==============
// 模拟数据请求：执行方法，发送一个数据请求，传递的值是请求的时间，请求成功后的结果也是这个值
const query = interval => {
    return new Promise(resolve => {
        setTimeout(() => {
            resolve(interval);
        }, interval);
    });
};

// 需求：我们有三个请求，所用时间分别是1000/2000/3000，而且实现的需要时“串行”「第一个请求成功，再发第二个请求，第二个请求成功，再发第三个请求 ->都成功需要的总时间是6000ms」
/* 
query(1000).then(result => {
    console.log(`第一个请求成功，结果是:${result}`);
    return query(2000);
}).then(result => {
    console.log(`第二个请求成功，结果是:${result}`);
    return query(3000);
}).then(result => {
    console.log(`第三个请求成功，结果是:${result}`);
}); 
*/

/* function* generator() {
    let result;
    result = yield query(1000);
    console.log(`第一个请求成功，结果是:${result}`);

    result = yield query(2000);
    console.log(`第二个请求成功，结果是:${result}`);

    result = yield query(3000);
    console.log(`第三个请求成功，结果是:${result}`);
}
let itor = generator();
// console.log(itor.next()); //value:promise  done:false
itor.next().value.then(result => {
    itor.next(result).value.then(result => {
        itor.next(result).value.then(result => {
            itor.next(result);
        });
    });
}); */


function isPromise(x) {
    if (x == null) return false;
    if (/^(object|function)$/i.test(typeof x)) {
        if (typeof x.then === "function") {
            return true;
        }
    }
    return false;
}
// 依次去执行生成器函数中每一个操作：itor.next()  co.js
//   + generator:要处理的生成器函数
//   + params:存储给生成器函数传递的实参信息
function AsyncFunction(generator, ...params) {
    return new Promise(resolve => {
        let itor = generator(...params);
        const next = x => {
            let {
                value,
                done
            } = itor.next(x);
            if (done) {
                resolve(value);
                return;
            }
            if (!isPromise(value)) value = Promise.resolve(value);
            value.then(result => next(result))
                .catch(reason => itor.throw(reason));
        };
        next();
    });
}

/* AsyncFunction(function* generator(x, y) {
    console.log(x, y);
    let result = yield query(1000);
    console.log(`第一个请求成功，结果是:${result}`);

    result = yield query(2000);
    console.log(`第二个请求成功，结果是:${result}`);

    result = yield query(3000);
    console.log(`第三个请求成功，结果是:${result}`);
}, 100, 200).then(() => {
    // generator处理完成，执行这个操作
    console.log('全部处理完成');
}); */


// async await 是 generator+promise 的“语法糖”
(async () => {
    let result = await query(1000);
    console.log(`第一个请求成功，结果是:${result}`);

    result = await query(2000);
    console.log(`第二个请求成功，结果是:${result}`);

    result = await query(3000);
    console.log(`第三个请求成功，结果是:${result}`);
})();