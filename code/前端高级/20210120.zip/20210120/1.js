/*
 * JS本身就是面向对象的编程语言，而他本身也是基于面向对象的思想构建出来的语言
 *   面向对象思想
 *     对象：万物皆对象
 *     类：对“对象”的归类和细分
 *     实例：类中的具体成员
 * 
 *   JS中的类：内置类、自定义类
 *     内置类：
 *       每一种数据类型又有自己对应的内置类：Number、String、Boolean、Symbol、BigInt、Object（Array、RegExp、Date、Set、Map、ArrayBuffer...）、Function
 *       我们平时接触的具体值就是对应的类的实例，例如：10就是Number类的一个实例，[10,20] -> Array -> Object ...
 *       ----
 *       每一个HTML元素标签「包含window/document等」在JS中都有自己的内置类，例如：div -> HTMLDivElement -> HTMLElement -> Element -> Node -> EventTarget -> Object
 *       ----
 *       ......
 */

function Fn(x, y) {
    let total = x + y,
        flag = false;
    this.total = total;
    this.say = function say() {
        console.log(this.total);
    };
}
/* let result = Fn(10, 20);
console.log(result); */

// “new”：构造函数执行 “标准面向对象的编程->构建自定义类”
//   + Fn被称为类「构造函数」
//   + result被称为当前类的一个实例
let result1 = new Fn(10, 20);
let result2 = new Fn(30, 40);
// console.log(result1.say === result2.say); //->false

//=================
// Object为每一个对象提供hasOwnProperty方法
//   obj.hasOwnProperty([attr])：检测attr是否是obj对象的私有属性
//   [attr] in obj：检测attr是否为obj的一个属性「不论私有还是公有」
/* 
console.log(result1.hasOwnProperty('say')); //->true
console.log(result1.hasOwnProperty('hasOwnProperty')); //->false  result1可以调用hasOwnProperty，说明hasOwnProperty是result1的一个成员「属性」
console.log('say' in result1); //->true
console.log('hasOwnProperty' in result1); //->true 
*/
// 面试题：自己编写一个方法 hasPubProperty 检测某个属性是否为对象的公有属性
/* 
function hasPubProperty(obj, attr) {
    // 思路：基于in检测结果是TRUE「是它的一个属性」 & 基于hasOwnProperty检测结果是false「不是私有的」，那么一定是公有的属性
    return (attr in obj) && !obj.hasOwnProperty(attr);
}
console.log(hasPubProperty(result1, 'hasOwnProperty')); //->true
console.log(hasPubProperty(result1, 'say')); //->false 
*/
// 弊端：只能是这种情况“某个属性不是私有的而是公有的”，但是如果这个属性 私有中也有&&公有中也有 ，基于我们的这个方法结果是false，但是这个属性确实也是他的公有属性，如何处理？

// 对象的循环 for in 循环
// let arr = [10, 20, 30];
/* 
// for循环本质不是遍历数组，是自己控制一个循环的逻辑  
//   “i=0 i<3 i++” 自己控制循环三次
//   每一轮循环i的值，恰好是我们想获取当前数组中这一项的索引「i从零开始，数组索引也是从零开始」，所以再基于成员访问获取即可
for (let i = 0; i < arr.length; i++) {
    console.log(arr[i], i);
}
*/
/* 
// for in本质是迭代对象，按照本身的键值对去一一迭代的
for (let key in arr) {
    console.log(arr[key], key);
}
*/
// for in内置的缺陷
//   + 不能迭代Symbol属性
//   + 迭代的时候不一定按照自己编写的键值对顺序迭代「优先迭代数字属性{小->大}，再去迭代非数字属性{自己编写顺序}」
//   + 不仅会迭代对象的私有属性，对于一些自己扩展的公有属性也会迭代到「迭代可枚举的{一般设定的都是可枚举的，内置的是不可枚举的}」
Object.prototype.sum = function sum() {};
let obj = {
    name: 'zhufeng',
    age: 12,
    0: 100,
    1: 200,
    teacher: 'zhouxiaotian',
    [Symbol('AA')]: 300
};
/* for (let key in obj) {
    console.log(key); //'0' '1' 'name' 'age' 'teacher' 'sum'
} */
/* // 只是不想迭代公有的「即使内部机制找到了，我们也不让其做任何的处理」
for (let key in obj) {
    // 先找所有私有，一但发现这个是公有的，说明私有的都找完了「不含Symbol」
    if (!obj.hasOwnProperty(key)) break;
    console.log(key);
} */

// Object.getOwnPropertySymbols(obj):获取对象所有Symbol的私有属性「数组」
// Object.keys(obj) || Object.getOwnPropertyNames(obj):获取对象所有非Symbol的私有属性「数组」
function each(obj, callback) {
    let keys = Object.keys(obj),
        key = null,
        value = null,
        i = 0,
        len = 0;
    if (typeof Symbol !== "undefined") {
        // 支持Symbol
        keys = keys.concat(Object.getOwnPropertySymbols(obj));
    }
    len = keys.length;
    if (typeof callback !== "function") callback = function () {};
    for (; i < len; i++) {
        key = keys[i];
        value = obj[key];
        callback(value, key);
    }
}
each(obj, (value, key) => {
    console.log(value, key);
});

//==================
// instanceof：检测某个实例是否率属于这个类
// console.log(result instanceof Fn); //->true

// 创建值有两种办法：
//    + 字面量方案
//    + 构造函数方案
// let obj1 = {};
// let obj2 = new Object();

// let n1 = 10; //Number类的一个实例「原始值」
// let n2 = new Number(10); //Number类的一个实例「对象」
// console.log(n2.toFixed(2)); //->10.00
// console.log(n1.toFixed(2)); //->10.00  内部处理机制“装箱和拆箱”：10->Object(10) 「对象实例」
// console.log(n1 + 10); //->20
// console.log(n2 + 10); //->20  n2对象Symbol.toPrimitive/valueOf
// console.log(n2 instanceof Number); //->true
// console.log(n1 instanceof Number); //->false  instanceof它的局限性：不能识别原始值