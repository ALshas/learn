/*
 * 浏览器是多线程的「同时做多件事情」
 *   + GUI渲染线程
 *   + JS引擎线程「渲染解析JS的」
 *   + DOM/定时器监听等线程
 *   + HTTP网络线程
 *   + ...
 * 
 * JS是单线程的
 *   情况：同时只能处理一件事情「上面代码没有执行完，下面代码是不能执行的」 => “同步编程”
 *        JS中大部分代码都是同步编程的
 * 
 * JS中有部分操作是异步编程
 *   + 但是绝对不是类似于多线程开发中的同时做多件事情，他一次只能处理一件事，因为是单线程；如果“JS引擎线程”正在解析JS代码，处理某个任务，那么其他什么事情都处理不了！！
 *   + 浏览器基于 EventQueue事件队列  EventLoop事件循环  两大机制，构建出来“异步编程的效果” =>单线程异步操作
 * ---------
 *  「异步宏任务」
 *      + 定时器
 *      + DOM事件
 *      + HTTP请求（ajax、fetch、jsonp...）
 *      + ...
 * 
 *  「异步微任务」
 *      + promise「resolve/reject/then...」
 *      + async await 
 *      + requestAnimationFrame
 *      + ...
 */

setTimeout(function () {
    console.log(1);
}, 1000);
console.log(2);
new Promise(resolve => {
    console.log(3);
    resolve();
    console.log(4);
}).then(() => {
    // 任务3 ->同步没有结束就知道了
    // +执行then的时候就只知道实例状态，它会在未来直接把onfulfilledCallback执行「不存储了」
    // +不知道实例状态，才是把方法存储起来「因为之前执行resolve也建立了一个微任务，就是把存储的方法后期执行」
    console.log(5);
}).then(() => {
    // 任务4 ->同步没结束的时候不知道，执行任务3执行了才知道
    console.log(6);
});
console.log(7);
const fn = () => {
    console.log(9);
};
(async function () {
    console.log(8);
    await fn();
    // 任务5 ->同步还没有结束，fn执行完，我们就已经知道任务5是可以执行的
    console.log(10);
    await fn();
    // 任务6
    console.log(11);
})();
console.log(12);