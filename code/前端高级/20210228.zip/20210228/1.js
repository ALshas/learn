/* import axios from './http.js';
import instance from './http_file.js'; */
import request from './fetch_handle.js';
/*
 * https://developer.mozilla.org/zh-CN/docs/Web/API/Fetch_API/Using_Fetch 
 * 
 * 前后端数据交互
 *    XMLHttpRequest「ajax请求」  传统方案{IE6:ActiveXObject}
 *       + $.ajax JQ中基于回调函数方式封装的ajax库
 *       + axios 基于Promise管理ajax请求『对ajax请求的封装』
 * 
 *    Fetch是基于新的通信方案完成客户端和服务器端的数据交互「不是XMLHttpRequest」
 *       + ES6内置类
 *       + 默认是基于Promise管理异步编程
 * 
 *    某些跨域方案
 *       + proxy/cors「基于XMLHttpRequest/Fetch发送请求，但是可以实现跨域」
 *       + jsonp
 *       + postMesage + iframe
 *       + ...
 */
//=============
/* request('/user/list', {
    method: 'GET', //*GET POST HEAD DELETE PUT ...
    params: { //基于问号参数传递给服务器
        lx: 0,
        name: 'zhufeng'
    },
    body: { //在POST系列请求中，我们可以把BODY对象处理成为我们想要的格式URLENCODED/JSON

    },
    headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
    },
    credentials: true,
    responseType: 'JSON' //*JSON TEXT BLOB ARRAYBUFFER
}).then(data => {

}); */

request('/user/list').then(data => {
    console.log(data);
});

request('/user/info', {
    params: {
        userId: 1
    }
}).then(data => {
    console.log(data);
});

request('/user/login', {
    method: 'POST',
    body: {
        account: '18310612838',
        password: md5('1234567890')
    }
}).then(data => {
    console.log(data);
});


//=============
/* fetch('http://127.0.0.1:9999/user/list?lx=0&name=zhufeng', {
    method: 'GET',
    headers: {},
    cache: 'no-cache',
    credentials: 'include'
});
fetch('http://127.0.0.1:9999/user/login', {
    method: 'POST',
    body: Qs.stringify({
        account: '18310612838',
        password: md5('1234567890')
    }),
    headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
    }
}); */

//=============
/* axios.get('/user/list').then(data => {
    console.log(data);
});

axios.post('/user/login', {
    account: '18310612838',
    password: md5('1234567890')
}).then(data => {
    console.log(data);
});

axios.get('/home_banner', {
    baseURL: 'http://127.0.0.1:8888',
    withCredentials: false
}).then(data => {
    console.log(data);
}); */

//=============
/* axios({
    url: 'http://127.0.0.1:9999/user/list',
    method: 'GET',
    params: {
        // GET系列请求基于问号传参把信息传递给服务器
        lx: 0,
        name: 'zhufeng'
    },
    headers: {
        // 自定义请求头信息
        'Authorization': 'token...'
    }
}).then(response => {
    console.log(response.data);
});


axios.get('http://127.0.0.1:9999/user/info', {
    params: {
        userId: 1
    }
}).then(response => {
    console.log(response.data);
});

// POST是基于请求主体把信息传递给服务器，数据格式要求
// 数据格式         请求头:Content-Type{MIME}  例子
// 「raw」
// json格式字符串     application/json        '{"account":"18310612838"...}'  默认
// xml格式字符串      application/xml
// 普通字符串         text/plain
// 「binary」
// 传输的是文件流信息「buffer & 二进制...」
// 「其余格式」
// urlencoded格式字符串  application/x-www-form-urlencoded   account=xxx&password=xxx
// form-data格式      multipart/form-data     文件上传「把文件对象{文件流信息}传递给服务器」& 表单提交
axios.post('http://127.0.0.1:9999/user/login', {
    // data
    account: '18310612838',
    password: md5('1234567890')
}, {
    // POST系列请求下：把传递进来的DATA对象,变为自己想要的格式
    transformRequest: (data, headers) => {
        // Qs.stringify/parse实现urlencoded格式字符串和对象之间的转换
        return Qs.stringify(data);
    },
    headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
    }
}).then(response => {
    console.log(response.data);
});
 */

/* fileInp.onchange = function () {
    let file = fileInp.files[0];
    if (!file) return;

    let fm = new FormData;
    fm.append('file', file);
    axios.post('http://127.0.0.1:9999/user/login', fm);
}; */


//=============
/* fetch('http://127.0.0.1:9999/user/list', {
    method: 'GET'
}).then(response => {
    // Response类的实例：text/json/blob/arrayBuffer方法 -> 返回的是新的promise实例「目的是把服务器返回的响应主体信息变为我们想要的格式数据」
    return response.json();
}).then(data => {
    console.log(data);
}); */

//=============
/* let xhr = new XMLHttpRequest;
xhr.open('GET', 'http://127.0.0.1:9999/user/list');
xhr.onreadystatechange = function () {
    if (xhr.readyState === 4 && xhr.status === 200) {
        console.log(xhr.responseText);
    }
};
xhr.send(); */

/* $.ajax({
    url: 'http://127.0.0.1:9999/user/list',
    method: 'GET',
    dataType: 'json',
    success(data) {
        // data就是从服务器获取的结果
        console.log(data);
    }
}); */

/* 
// 数据请求成功，会让返回的promise实例变为成功
axios.get('http://127.0.0.1:9999/user/list').then(response => {
    console.log(response.data);
}); 
*/