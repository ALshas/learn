/*
   从输入URL地址到看到页面，中间都经历了啥
     1.URL解析「识别URL」
     2.检查缓存「强缓存、协商缓存{针对于资源文件请求} & 本地存储{针对于数据请求}」
     3.DNS服务器解析「域名解析：根据域名解析出服务器的外网IP」
     4.TCP三次握手「建立客户端和服务器之间的网络连接通道」
     5.基于HTTP/HTTPS等传输协议，实现客户端和服务器之间的信息通信
     6.TCP四次挥手「把建立好的网络通道释放掉」
     7.客户端渲染「呈现出页面和效果」
 */

/* 
 * 数据缓存的需求
 *   没有缓存数据，我们从服务器拉取最新数据；有缓存数据，我们直接读取缓存的数据「减少和服务器之间的交互频率，降低服务器压力，也可以提高页面的渲染速度...」；
 *   ->页面不刷新，我们某些内容频繁操作，但是数据不是需要事实获取最新的，则可以做一下缓存；只要页面刷新，重新从服务器获取数据；
 *   ->页面只要不关闭，我们读取缓存数据「针对于不经常更新的数据」；
 *   ->页面即使关闭，重新打开，我们也可以读取缓存中的数据「数据更新的频率更低，我们自己设定过期周期」；
 *   ->...
 * 
 * 客户端存储数据的方案？
 *   + (全局)变量存储「vuex/redux」：页面刷新或者关闭后重新打开，之前存储的数据都没有了（内存释放问题导致的）
 *   + cookie
 *   + webStorage：localStorage & sessionStorage
 *   + IndexedDB
 *   + Cache
 *   + Manifest 离线存储
 *   + ...
 * 
 * localStorage VS sessionStorage
 *   HTML5新增的API「不兼容IE8及以下浏览器」
 *   localStorage持久化本地存储「没有过期时间」，页面关闭存储的内容也是在的，只有手动清除(或者卸载浏览器)才会清除
 *   sessionStorage会话存储，页面关闭后，存储的信息会消失「但是页面刷新是不消失的」
 * 
 * localStorage VS cookie
 *   本地存储的数据是有同源访问限制的，只允许读取本源下存储的内容
 *   + cookie只允许一个源下最多存储4KB内容，所以不能存储太多的数据！localStorage可以同源下存储5MB内容！
 *   + cookie是需要设置过期时间的，超过时间就失效了，并且有路径等限制！localStorage是持久化存储，没有过期时间，除非自己设定一些过期的处理机制！
 *   + cookie不稳定「基于安全卫士或者浏览器自带的清除操作，会把cookie干掉；开启无痕浏览或者隐私模式，则不能存储cookie信息！但是localStorage不受这些操作的影响！
 *   + cookie兼容低版本浏览器
 *   + cookie不算严格的本地存储，和服务器之间有很多的“猫腻”「客户端向服务器发送请求的时候，会默认把本地的cookie信息，基于请求头发送给服务器；并且如果服务器返回的响应头中有Set-Cookie字段，浏览器也会默认把这些信息在客户端本地种上cookie...」！localStorage是严格本地存储，默认情况下和服务器没有关系也没有“猫腻”！
 */

// let submit = document.querySelector('#submit'),
//    runing = false;

/* let serverData;
submit.onclick = function () {
   if (runing) return;
   runing = true;

   if (serverData) {
      // 如果有数据，直接使用缓存数据，无需从服务器获取
      console.log('请求回来的数据是：', serverData);
      runing = false;
      return;
   }

   // 从服务器拉去数据，并其存储到全局变量中
   axios.get('http://127.0.0.1:8888/home_banner').then(response => {
      console.log('请求回来的数据是：', response.data);
      serverData = response.data;
      runing = false;
   });
}; */


/* submit.onclick = function () {
   if (runing) return;
   runing = true;

   let data = sessionStorage.getItem('@A');
   if (data) {
      // 如果有数据，直接使用缓存数据，无需从服务器获取
      console.log('请求回来的数据是：', JSON.parse(data));
      runing = false;
      return;
   }

   // 从服务器拉去数据，并其存储到全局变量中
   axios.get('http://127.0.0.1:8888/home_banner').then(response => {
      console.log('请求回来的数据是：', response.data);
      sessionStorage.setItem('@A', JSON.stringify(response.data));
      runing = false;
   });
}; */


/* submit.onclick = function () {
   if (runing) return;
   runing = true;

   let data = localStorage.getItem('@A');
   if (data) {
      data = JSON.parse(data);
      // 自己可以设定过期的标准 1小时
      if (new Date() - data.time <= 60 * 60 * 1000) {
         console.log('请求回来的数据是：', data.data);
         runing = false;
         return;
      }
   }

   // 从服务器拉去数据，并其存储到全局变量中
   axios.get('http://127.0.0.1:8888/home_banner').then(response => {
      console.log('请求回来的数据是：', response.data);
      localStorage.setItem('@A', JSON.stringify({
         time: +new Date(),
         data: response.data
      }));
      runing = false;
   });
}; */